package vn.com.claim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimApplicationTests {

	@Test
	void contextLoads() {
	}

}
